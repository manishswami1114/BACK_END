const express=require("express");
const fs=require("fs");
const app=express();
app.use(express.static("."));
app.use(express.urlencoded());


app.post("/login",(req,res)=>{

   console.log(req.body);
   fs.readFile("./pass.txt","utf-8",(err,data)=>{

    let records=JSON.parse(data);

   let results= records.filter((item)=>{
    if(item.username==req.body.username && item.password==req.body.password)
    return true;

    });

    if(results.length==0)
    fs.readFile("./index.html","utf-8",(err,data)=>{

        res.send(data);
    })
else
fs.readFile("./home.html","utf-8",(err,data)=>{
    res.send(data);
})



   })

})
app.listen(4000,(err)=>{

    if(err)
    console.log("Unable to start server...");
else
console.log("Server Started...")
})